import base64
import hashlib
import hmac
import secrets
from dataclasses import dataclass, field
from types import MappingProxyType
from typing import NamedTuple, Optional
from urllib.parse import urlencode

import requests


class PKCEPair(NamedTuple):
    code_verifier: str
    code_challenge: str


def generate_pkce_pair() -> PKCEPair:
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return PKCEPair(verifier, challenge)


@dataclass
class OAuthUser:
    provider: str
    provider_id: str
    email: Optional[str] = None
    name: Optional[str] = None
    email_verified: Optional[bool] = None
    raw: Optional[dict] = field(default=None, repr=False)


class OAuthError(Exception):
    pass


class OAuthTokenError(OAuthError):
    pass


class OAuthUserInfoError(OAuthError):
    pass


PROVIDER_CONFIG = MappingProxyType(
    {
        "kakao": MappingProxyType(
            {
                "authorize_url": "https://kauth.kakao.com/oauth/authorize",
                "token_url": "https://kauth.kakao.com/oauth/token",
                "userinfo_url": "https://kapi.kakao.com/v2/user/me",
                "supports_pkce": False,
            }
        ),
        "naver": MappingProxyType(
            {
                "authorize_url": "https://nid.naver.com/oauth2.0/authorize",
                "token_url": "https://nid.naver.com/oauth2.0/token",
                "userinfo_url": "https://openapi.naver.com/v1/nid/me",
                "supports_pkce": False,
            }
        ),
        "google": MappingProxyType(
            {
                "authorize_url": "https://accounts.google.com/o/oauth2/v2/auth",
                "token_url": "https://oauth2.googleapis.com/token",
                "userinfo_url": "https://www.googleapis.com/oauth2/v2/userinfo",
                "supports_pkce": True,
            }
        ),
        "github": MappingProxyType(
            {
                "authorize_url": "https://github.com/login/oauth/authorize",
                "token_url": "https://github.com/login/oauth/access_token",
                "userinfo_url": "https://api.github.com/user",
                "supports_pkce": True,
            }
        ),
    }
)


def _require_provider_id(provider: str, provider_id: object) -> str:
    if provider_id is None or provider_id == "":
        raise ValueError(f"Missing provider user id for {provider}")
    return str(provider_id)


def _email_if_verified(email: Optional[str], verified: Optional[bool]) -> Optional[str]:
    return email if verified is True else None


def _is_github_noreply_email(email: Optional[str]) -> bool:
    if not email:
        return False
    return email.endswith("@users.noreply.github.com") or email.endswith(
        "@users.github.com"
    )


def _detect_userinfo_error(data: dict) -> Optional[str]:
    if data.get("error"):
        return str(data["error"])
    code = data.get("code")
    if isinstance(code, int) and code < 0:
        return f"{data.get('msg', 'unknown error')} (code={code})"
    resultcode = data.get("resultcode")
    if isinstance(resultcode, str) and resultcode != "00":
        return f"{data.get('message', 'unknown error')} (resultcode={resultcode})"
    return None


def _extract_kakao(raw: dict, provider: str) -> OAuthUser:
    account = raw.get("kakao_account", {})
    profile = account.get("profile", {})
    email_verified = account.get("is_email_verified")
    return OAuthUser(
        provider=provider,
        provider_id=_require_provider_id(provider, raw.get("id")),
        email=_email_if_verified(account.get("email"), email_verified),
        name=profile.get("nickname"),
        email_verified=email_verified,
        raw=raw,
    )


def _extract_naver(raw: dict, provider: str) -> OAuthUser:
    response = raw.get("response", {})
    email = response.get("email")
    return OAuthUser(
        provider=provider,
        provider_id=_require_provider_id(provider, response.get("id")),
        email=email,
        name=response.get("name"),
        email_verified=True if email else None,
        raw=raw,
    )


def _extract_google(raw: dict, provider: str) -> OAuthUser:
    email_verified = raw.get("email_verified", raw.get("verified_email"))
    return OAuthUser(
        provider=provider,
        provider_id=_require_provider_id(provider, raw.get("id")),
        email=_email_if_verified(raw.get("email"), email_verified),
        name=raw.get("name"),
        email_verified=email_verified,
        raw=raw,
    )


def _extract_github(raw: dict, provider: str) -> OAuthUser:
    email = raw.get("email")
    if _is_github_noreply_email(email):
        email = None
    return OAuthUser(
        provider=provider,
        provider_id=_require_provider_id(provider, raw.get("id")),
        email=email,
        name=raw.get("name") or raw.get("login"),
        email_verified=True if email else None,
        raw=raw,
    )


USER_EXTRACTORS = {
    "kakao": _extract_kakao,
    "naver": _extract_naver,
    "google": _extract_google,
    "github": _extract_github,
}


def generate_state() -> str:
    return secrets.token_urlsafe(32)


def verify_state(expected_state: str, returned_state: str) -> bool:
    if not expected_state or not returned_state:
        return False
    return hmac.compare_digest(expected_state, returned_state)


class OAuthClient:
    def __init__(self, provider: str, client_id: str, client_secret: str):
        if provider not in PROVIDER_CONFIG:
            raise ValueError(
                f"Unsupported provider: {provider}. "
                f"Choose from {list(PROVIDER_CONFIG.keys())}"
            )
        self.provider = provider
        self.client_id = client_id
        self.client_secret = client_secret
        self.config = PROVIDER_CONFIG[provider]

    def get_authorize_url(
        self,
        redirect_uri: str,
        state: str,
        scope: str = "",
        code_challenge: Optional[str] = None,
    ) -> str:
        if not state:
            raise ValueError("state is required. Use generate_state().")
        if code_challenge and not self.config["supports_pkce"]:
            raise ValueError(f"{self.provider} does not support PKCE")
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "state": state,
        }
        scope = scope.strip()
        if scope:
            params["scope"] = scope
        if code_challenge:
            params["code_challenge"] = code_challenge
            params["code_challenge_method"] = "S256"
        return f"{self.config['authorize_url']}?{urlencode(params)}"

    def fetch_token(
        self,
        code: str,
        redirect_uri: str,
        code_verifier: Optional[str] = None,
    ) -> dict:
        if code_verifier and not self.config["supports_pkce"]:
            raise ValueError(f"{self.provider} does not support PKCE")
        data = {
            "grant_type": "authorization_code",
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "code": code,
            "redirect_uri": redirect_uri,
        }
        if code_verifier:
            data["code_verifier"] = code_verifier
        response = requests.post(
            self.config["token_url"],
            data=data,
            headers={"Accept": "application/json"},
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            raise OAuthTokenError("Token endpoint returned a non-object response")
        if data.get("error"):
            raise OAuthTokenError(f"Token endpoint error: {data['error']}")
        if not data.get("access_token"):
            raise OAuthTokenError("Token endpoint response missing access_token")
        return data

    def fetch_user(self, access_token: str) -> OAuthUser:
        response = requests.get(
            self.config["userinfo_url"],
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=10,
        )
        response.raise_for_status()
        data = response.json()
        if not isinstance(data, dict):
            raise OAuthUserInfoError("Userinfo endpoint returned a non-object response")
        error = _detect_userinfo_error(data)
        if error:
            raise OAuthUserInfoError(f"Userinfo endpoint error: {error}")
        return USER_EXTRACTORS[self.provider](data, self.provider)
